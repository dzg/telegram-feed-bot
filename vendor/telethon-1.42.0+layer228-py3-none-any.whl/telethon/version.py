# Versions should comply with PEP440.
# This line is parsed in setup.py:
__version__ = '1.42.0+layer228'
